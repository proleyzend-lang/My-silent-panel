package com.example.myclient;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Switch;

public class FloatingOverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private static final String CHANNEL = "my_client_overlay";

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL)
                    .setContentTitle("My Client overlay is running")
                    .setContentText("Use the floating panel or tap Close to stop it.")
                    .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        } else {
            notification = new Notification.Builder(this)
                    .setContentTitle("My Client overlay is running")
                    .setContentText("Use the floating panel or tap Close to stop it.")
                    .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        }
        startForeground(41, notification);
        showOverlay();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "My Client overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 14, 18, 14);
        box.setBackgroundColor(Color.rgb(26, 26, 38));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("◆ MY CLIENT"); title.setTextColor(Color.rgb(255, 60, 90)); title.setTextSize(16); title.setPadding(0, 0, 18, 0);
        Button close = new Button(this); close.setText("Close"); close.setTextSize(10);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1)); header.addView(close);
        box.addView(header);
        addSwitch(box, "ES"); addSwitch(box, "AIM"); addSwitch(box, "FL");
        TextView note = new TextView(this); note.setText("Demo switches only"); note.setTextColor(Color.LTGRAY); note.setTextSize(10); box.addView(note);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = 24; params.y = 180;
        box.setElevation(12f);
        box.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY; private float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: startX=params.x; startY=params.y; downX=event.getRawX(); downY=event.getRawY(); return false;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int)(event.getRawX()-downX); params.y = startY + (int)(event.getRawY()-downY);
                        try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {} return true;
                }
                return false;
            }
        });
        close.setOnClickListener(v -> stopSelf());
        panel = box;
        try { wm.addView(panel, params); } catch (Exception e) { stopSelf(); }
    }

    private void addSwitch(LinearLayout parent, String label) {
        Switch s = new Switch(this); s.setText(label + "  "); s.setTextColor(Color.WHITE); s.setTextSize(14);
        s.setPadding(0, 5, 0, 5);
        // UI demonstration only: these switches do not control or modify other apps.
        parent.addView(s);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() {
        if (wm != null && panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        stopForeground(true); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
