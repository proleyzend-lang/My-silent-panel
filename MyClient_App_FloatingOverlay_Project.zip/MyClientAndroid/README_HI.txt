MY CLIENT — Android source project (app + floating overlay)

Is project mein:
- App kholne par HTML wala MY CLIENT display aata hai.
- “Show Floating Overlay” dabane par Android ka “Display over other apps” permission page khulega.
- Permission allow karne ke baad floating panel doosri apps ke upar bhi dikhega.
- Panel ko drag kar sakte hain aur Close se band kar sakte hain.
- ES/AIM/FL switches sirf demo UI hain. Ye kisi game/app ko modify, aim, automate ya control nahi karte.

IMPORTANT: Yeh source project hai, compiled APK nahi.

Build karne ke liye:
1. Project ko Android Studio mein open karein (computer par easiest).
2. Gradle sync hone dein.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Sirf mobile se APK banana ho to Android Studio project ko seedha install nahi kiya ja sakta; mobile-compatible cloud build/IDE ka setup alag karna padega. Android 6+ par overlay permission user ko khud Settings mein allow karni hoti hai.
